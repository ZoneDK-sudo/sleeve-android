# Sleeve for Android

Moving album art and music-video visuals that react to whatever plays on your phone, Spotify included.

## Get the APK without installing anything (GitHub, free)

1. Sign in at github.com and create a new repository (any name, can be private).
2. On the new repo page, choose "uploading an existing file" and drag in everything from this folder.
   If the `.github` folder doesn't come along (some computers hide it), open the Actions tab,
   choose "set up a workflow yourself", and paste in the contents of `.github/workflows/build.yml`.
3. Open the Actions tab. "Build APK" runs on its own (about 3–5 minutes). If it doesn't, pick it and press "Run workflow".
4. When it shows a green tick, open the run and download `sleeve-apk` at the bottom. Unzip it to get `app-debug.apk`.
5. Copy the APK to your phone, open it, and allow installing from that source when Android asks.

## Or build it with Android Studio

Open this folder in Android Studio, let it sync, then use Build > Build APK(s).

## Using it

- Start a song in Spotify, open Sleeve, tap Set up, then "Listen to phone audio". Allow the audio permission.
  Sleeve reads the phone's sound output through Android's built-in visualizer, so nothing goes through the mic.
- If phone audio stays flat on your device (a few manufacturers block it), use "Listen through the mic" instead.
- Recorded clips save to Movies/Sleeve. Clips made with phone audio have picture only; clips from an audio file include the sound.

Needs Android 10 or newer.
