package app.sleeve.visuals;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.audiofx.Visualizer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int REQ_MIC_WEB = 1, REQ_MIC_PHONE = 2, REQ_FILE = 3;
    private static final String START_URL = "https://appassets.androidplatform.net/assets/index.html";

    private WebView web;
    private WebViewAssetLoader loader;
    private PermissionRequest pendingWebPerm;
    private ValueCallback<Uri[]> fileCallback;

    private Visualizer vis;
    private byte[] lastWave;
    private volatile byte[] frame;
    private volatile int frameSeq = 0;
    private int sentSeq = -1;
    private int bins, waveLen;

    private OutputStream saveOut;
    private Uri saveUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        getWindow().setAttributes(lp);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

        web = new WebView(this);
        web.setBackgroundColor(0xFF160F1C);
        setContentView(web);
        hideBars();

        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(false);

        loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean wantsMic = false;
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) wantsMic = true;
                    }
                    if (!wantsMic) { request.deny(); return; }
                    if (hasMic()) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    } else {
                        pendingWebPerm = request;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC_WEB);
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl(START_URL);
    }

    private void hideBars() {
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        c.hide(WindowInsetsCompat.Type.systemBars());
        c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    private boolean hasMic() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_MIC_WEB && pendingWebPerm != null) {
            if (ok) pendingWebPerm.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            else pendingWebPerm.deny();
            pendingWebPerm = null;
        } else if (requestCode == REQ_MIC_PHONE) {
            if (ok) startVisualizer();
            else report("denied", "null");
        }
    }

    /* Listens to the phone's overall audio output (Spotify included) through Android's Visualizer. */
    private void startVisualizer() {
        stopVisualizer();
        try {
            vis = new Visualizer(0);
            int[] range = Visualizer.getCaptureSizeRange();
            int size = Math.min(1024, range[1]);
            vis.setCaptureSize(size);
            vis.setScalingMode(Visualizer.SCALING_MODE_NORMALIZED);
            waveLen = size;
            bins = size / 2;
            lastWave = new byte[size];
            java.util.Arrays.fill(lastWave, (byte) 128);
            double binHz = vis.getSamplingRate() / 1000.0 / size;

            vis.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                @Override
                public void onWaveFormDataCapture(Visualizer v, byte[] w, int rate) {
                    System.arraycopy(w, 0, lastWave, 0, Math.min(w.length, lastWave.length));
                }

                @Override
                public void onFftDataCapture(Visualizer v, byte[] fft, int rate) {
                    byte[] out = new byte[bins + waveLen];
                    out[0] = mag(fft[0], 0);
                    for (int k = 1; k < bins && 2 * k + 1 < fft.length; k++) out[k] = mag(fft[2 * k], fft[2 * k + 1]);
                    System.arraycopy(lastWave, 0, out, bins, waveLen);
                    frame = out;
                    frameSeq++;
                }
            }, Visualizer.getMaxCaptureRate(), true, true);
            vis.setEnabled(true);

            JSONObject info = new JSONObject();
            info.put("bins", bins);
            info.put("binHz", binHz);
            info.put("waveLen", waveLen);
            report("ok", info.toString());
        } catch (Exception e) {
            stopVisualizer();
            report("error", JSONObject.quote(String.valueOf(e.getMessage())));
        }
    }

    private static byte mag(byte re, byte im) {
        double m = Math.hypot(re, im);
        double db = 20 * Math.log10(m + 1e-6);
        double v = Math.max(0, Math.min(1, (db - 6) / 38.0));
        return (byte) Math.round(v * 255);
    }

    private void stopVisualizer() {
        if (vis != null) {
            try { vis.setEnabled(false); } catch (Exception ignored) { }
            vis.release();
            vis = null;
        }
        frame = null;
    }

    private void report(String state, String json) {
        runOnUiThread(() -> web.evaluateJavascript(
                "window.__phoneAudio&&window.__phoneAudio(" + JSONObject.quote(state) + "," + json + ")", null));
    }

    private void closeSave() {
        try { if (saveOut != null) saveOut.close(); } catch (Exception ignored) { }
        saveOut = null;
    }

    @Override
    protected void onDestroy() {
        stopVisualizer();
        closeSave();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private class Bridge {
        @JavascriptInterface
        public void startPhoneAudio() {
            runOnUiThread(() -> {
                if (hasMic()) startVisualizer();
                else requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC_PHONE);
            });
        }

        @JavascriptInterface
        public void stopPhoneAudio() {
            runOnUiThread(MainActivity.this::stopVisualizer);
        }

        @JavascriptInterface
        public String getFrame() {
            byte[] f = frame;
            int seq = frameSeq;
            if (f == null || seq == sentSeq) return "";
            sentSeq = seq;
            return Base64.encodeToString(f, Base64.NO_WRAP);
        }

        @JavascriptInterface
        public String saveBegin(String name, String mime) {
            try {
                closeSave();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Sleeve");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                saveUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
                if (saveUri == null) return "could not create the file";
                saveOut = getContentResolver().openOutputStream(saveUri);
                return saveOut == null ? "could not open the file" : "ok";
            } catch (Exception e) {
                return String.valueOf(e.getMessage());
            }
        }

        @JavascriptInterface
        public String saveChunk(String b64) {
            try {
                saveOut.write(Base64.decode(b64, Base64.DEFAULT));
                return "ok";
            } catch (Exception e) {
                return String.valueOf(e.getMessage());
            }
        }

        @JavascriptInterface
        public String saveEnd() {
            try {
                closeSave();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(saveUri, v, null, null);
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Saved to Movies/Sleeve", Toast.LENGTH_LONG).show());
                return "ok";
            } catch (Exception e) {
                return String.valueOf(e.getMessage());
            }
        }
    }
}
